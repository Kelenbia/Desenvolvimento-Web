function calcularResultado() {
    var pontos = 0;
    var msgErro = "";

    var resultadoDiv = document.getElementById("resultado");
    var erroDiv = document.getElementById("mensagensErro");

    // limpa mensagens antigas
    erroDiv.innerHTML = "";
    resultadoDiv.innerHTML = "";

   
    var radios = document.getElementsByName("q1");
    var valorQ1 = "";

    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            valorQ1 = radios[i].value;
        }
    }

    if (valorQ1 === "") {
        msgErro += "Responda a pergunta 1.<br>";
    } else if (valorQ1 === "marvel") { 
        pontos++;
    }

   
    var selectHerói = document.querySelector("#q2");
    var valorQ2 = selectHerói.value;

    if (valorQ2 === "") {
        msgErro += "Responda a pergunta 2.<br>";
    } else if (valorQ2 === "batman") { 
        pontos++;
    }

    
    var checksSelecionados = document.querySelectorAll("input[name='q3']:checked");

    if (checksSelecionados.length === 0) {
        msgErro += "Responda a pergunta 3.<br>";
    } else {
        var temFerro = false;
        var temCapita = false;
        var marcouOutros = false;

        for (var j = 0; j < checksSelecionados.length; j++) {
            var valor = checksSelecionados[j].value;

            if (valor === "homemdeferro") {
                temFerro = true;
            } else if (valor === "capitamarvel") {
                temCapita = true;
            } else {
                
                marcouOutros = true;
            }
        }

       
        if (temFerro && temCapita && !marcouOutros) {
            pontos++;
        }
    }

   
    if (msgErro !== "") {
        erroDiv.innerHTML = msgErro;
        resultadoDiv.innerHTML =
            "Preencha todas as perguntas para ver o resultado do seu quiz.";
        return;
    }

   
    var textoPontuacao = "Você fez " + pontos + " de 3 pontos.";
    resultadoDiv.innerHTML = textoPontuacao;

    
    var paragrafoFeedback = document.createElement("p");

    if (pontos === 3) {
        paragrafoFeedback.textContent =
            "Parabéns! Você é uma verdadeira fã do universo dos super-heróis.";
    } else if (pontos === 2) {
        paragrafoFeedback.textContent =
            "Mandou bem! Falta pouco para virar especialista em Marvel e DC.";
    } else {
        paragrafoFeedback.textContent =
            "Tá na hora de maratonar uns filmes de heróis para melhorar essa pontuação!";
    }

    resultadoDiv.appendChild(paragrafoFeedback);
}

function limparResultado() {
    var resultadoDiv = document.getElementById("resultado");
    var erroDiv = document.getElementById("mensagensErro");

    erroDiv.innerHTML = "";
    resultadoDiv.innerHTML =
        'O resultado aparecerá aqui depois que você clicar em <strong>"Ver resultado"</strong>.';
}
